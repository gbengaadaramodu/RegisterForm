﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebRegistration.Models;

namespace WebRegistration.Controllers
{
    public class RegController : Controller
    {
        // GET: Reg
        public ActionResult index()
        {
            using (dbContext db = new dbContext())
            {
                return View(db.NewUsers.ToList());
            }
               
        }

        [HttpGet]
        public ActionResult Form(int id=0)
        {
            NewUser dataValue = new NewUser();
            return View();
        }

        [HttpPost]
        public ActionResult Form(NewUser dataValue)
        {
            if (ModelState.IsValid)
            {
                using(dbContext db= new dbContext())
                {
                    if(db.NewUsers.Any(temp=>temp.username == dataValue.username))
                    {
                        ViewBag.DuplicatedMessage = "Username is already existing.";
                        return View("Form",dataValue);
                    }
                    else
                    {
                        db.NewUsers.Add(dataValue);
                        db.SaveChanges();
                    }
                    ModelState.Clear();
                    ViewBag.SucMessage = "Register successfully";
                    
                }

            }

            return View("Form", new NewUser());
        }

        [HttpGet]
        public ActionResult Search(int id = 0)
        {
            NewUser searchView = new NewUser();

            return View();

        }

        [HttpPost]
        public ActionResult Search(NewUser searchView)
        {
            using(dbContext db= new dbContext())
            {

                try
                {
                    var result = db.NewUsers.Single(x => x.username == searchView.username);
                    if (result != null)
                    {
                        Session["username"] = result.username.ToString();
                        Session["title"] = result.title.ToString();
                        Session["firstname"] = result.firstname.ToString();
                        Session["lastname"] = result.lastname.ToString();
                        Session["gender"] = result.gender.ToString();
                        Session["datebirth"] = result.datebirth.ToString();
                        return View("Search");
                    }
                }

                catch (Exception ex)
                { 
                    ModelState.AddModelError("", "Username is not found.");
                    Session["title"] = string.Empty;
                    Session["firstname"] = string.Empty;
                    Session["lastname"] = string.Empty;
                    Session["gender"] = string.Empty;
                    Session["datebirth"] = string.Empty;
                }

            }
            return View();
        }

    }
}